# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 18:30:09 2019

@author: exame
"""

import math

def f(x):
    return (math.e**x)-x-2-2

def ff(x):
    return math.e**x-1

def newton(x):
    print("newton")
    for i in range(5):
        xold=x
        x=x-f(x)/ff(x)
        print("x=",x)
        print("precisao_absoluta=",abs(xold)-x)

def picard1(x):
    print("picard1")
    for i in range(5):
        xold=x
        x=math.e**x-2-2
        print("x=",x)
        print("precisao_absoluta=",abs(xold)-x)

def picard2(x):
    print("picard2")
    for i in range(5):
        xold=x
        x=math.log(2+x+2)
        print("x=",x)
        print("precisao_absoluta=",abs(xold)-x)
        
x=-2
newton(x)
picard2(x)
picard1(x)